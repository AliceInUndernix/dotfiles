[
  (list)
  (scope)
  (cons)
] @fold
