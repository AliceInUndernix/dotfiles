((section) @fold
  (#trim! @fold))
