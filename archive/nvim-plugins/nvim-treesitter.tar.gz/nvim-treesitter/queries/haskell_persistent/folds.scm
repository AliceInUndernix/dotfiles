(entity_definition) @fold
